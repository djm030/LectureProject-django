from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from .models import Video


class VideoSerializer(ModelSerializer):
    class Meta:
        model = Video
        fields = "__all__"


class VideoListSerializer(ModelSerializer):
    class Meta:
        model = Video
        fields = (
            "id",
            "title",
            "description",
            "videoLength",
        )


class VideoDetailSerializer(ModelSerializer):
    class Meta:
        model = Video
        fields = ("videoFile",)
